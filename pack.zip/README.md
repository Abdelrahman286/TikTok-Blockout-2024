# Take charge of your Tiktok timeline with one click

![alt text](screenshot1.png)

Link : https://chromewebstore.google.com/detail/tiktokblockout2024/bimhigeggaekhifnmhhmbjbeahooolig?hl=en-GB

How to use :

1. press `load` or add your list of accounts manually
2. press `start blocking` and wait until the whole list get blocked
3. preferably disable the extension to avoid any further automatic accounts blocking
